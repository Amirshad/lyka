<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<!--<meta http-equiv="refresh" content="0;URL='#'" />-->
<link rel="stylesheet" href="css/bootstrap.min.css">
<link href="css/custom.css" rel="stylesheet">
<link href="css/style.css" rel="stylesheet">
<link rel="stylesheet" href="css/owl.carousel.min.css">
<link rel="stylesheet" href="css/owl.theme.default.min.css">
<link rel="stylesheet" href="css/aos.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fancyapps/ui@4.0/dist/fancybox.css" />
<link rel="icon" type="image/png" href="images/img/favicon.png" />
<link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">